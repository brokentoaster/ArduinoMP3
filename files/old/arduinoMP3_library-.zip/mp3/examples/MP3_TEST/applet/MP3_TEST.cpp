
#define FAT_NumberedSong_EN 1

#include <utils.h>
#include <mmc.h>
#include <avrfat16.h>
#include <vs1001.h>
#include <types.h>

#include "WProgram.h"
void setup();
void loop();
unsigned char open_Dir(unsigned long dir_lba);
void hexprint(unsigned char d);
void dump_buffer(unsigned char lines, unsigned char buffer[]);
unsigned char MMC_tester(void);
void debug_trigger(char x);
uint8	FAT_tester(void);
void 	cue_file(void);
void 	streaming (void);
MMC card;
FAT16  vol;
vs1001 player;

char mp3_cs = 3;
char mp3_bsync = 2;
char mp3_dreq  = 15;
char mp3_reset = 14 ;
char debugpin = 8;

unsigned char	cluster_pos=0;		///< position in cluster 
unsigned char	buff_pos=16;		///< position in buffer

//////////////////////////////////// SETUP
void setup()
{
  char r;
  unsigned long lr;
   
  pinMode(debugpin,OUTPUT);           // setup debug trigger
  digitalWrite(debugpin, HIGH);

    
  digitalWrite(mp3_dreq, HIGH);       // turn on pullup resistors
  digitalWrite(mp3_bsync, LOW);       // turn off BSYNC
  digitalWrite(mp3_reset, LOW);       // turn off VS1003 
  digitalWrite(mp3_cs, HIGH);         // turn off VS10xx SPI
  
  pinMode(mp3_dreq, INPUT);           // set pin to input
  pinMode(mp3_bsync,OUTPUT);          // set pin to output
  pinMode(mp3_reset,OUTPUT);          // set pin to output
  pinMode(mp3_cs,OUTPUT);             // set pin to output
  
  Serial.begin(115200);
  Serial.println("TEST");


  r= card.reset();
    r= card.reset();
  Serial.println (r,DEC); 
  
  if (r!=0) while(1); // HALT
  
    r=MMC_tester();
    Serial.println(r,DEC);


  	// set up the FAT variables
      	vol.FAT_buffer = card.mmc_sbuf; 	// 512 byte buffer for sector reads/writes
      	vol.FAT_scratch = card.mmc_scratch; 
      	vol.rawDev = &card; // pointer to read block function 
      	vol.FAT16_entryMAX =-1;
      	vol.FAT16_entryMIN = 0;
        vol.gFAT_entry = 0; 

      r= vol.FAT_initFat16();
      Serial.print("FAT Init returned:");
      Serial.println(r,DEC);
      
        if (r!=0) while(1); // HALT
      FAT_tester();
      
    
//  player.init_io();
//  player.init_chip();
   debug_trigger(3);
 // player.sine_test();
  
 lr =  open_Dir(vol.FAT16_root_dir_first_sector);
  Serial.print("Files: ");
  Serial.println( lr);
  vol.gFAT_entry =  vol.FAT_getNextSong(vol.FAT16_entryMIN,vol.FAT16_dir_first_sector);

  Serial.println(  vol.gFAT_entry,HEX );
  
  cue_file();

  	unsigned short  buf[2];
  
  debug_trigger(3);
	player.setvolume(0, 0);
	
  //  player.read(SCI_MODE, 1, buf);
    
    //  buf[0]=0x0808;   

//    buf[0] |= SM_SDINEW ;

//	player.write(SCI_MODE,1,buf);

	buf[0] = 0x9800;
	player.write(SCI_CLOCKF,1,buf);	
        player.write(SCI_CLOCKF,1,buf);	
        
 Serial.println("DONE");
 vol.FAT_readCluster(vol.gCluster,cluster_pos);
}

//////////////////////////////////// LOOP
void loop() 
{
streaming();
      delay(1); 
}

unsigned char open_Dir(unsigned long dir_lba){
	unsigned char files =0;
	

	
	files = vol.FAT_scanDir_lba(dir_lba);
	
	vol.gFAT_entry= vol.FAT16_entryMIN;
	cue_file(); // load the file into memory
	
	// Display back to normal

	
	//PRINT("1ST FLE @ ");UART_Printfu16(FAT16_entryMIN);
	//PRINT("  LST FLE @ ");UART_Printfu16(FAT16_entryMAX);EOL();
	//UART_Printfu08(files);PRINT("files");EOL();
	
	return files;
}


void hexprint(unsigned char d){
  if (d<16 ) Serial.print('0',BYTE);
  Serial.print(d,HEX);
}


/***************************************************************************
*   Name:	dump_buffer
*	Description: Dumps the mmc_sbuf[] to the Uart
*	Parameters: <lines> # of lines (16 Bytes) to send starting from 0x00
*	Returns: 	none
***************************************************************************/
void dump_buffer(unsigned char lines, unsigned char buffer[])
{
	unsigned char c,i;
	for (c=0;c<lines;c++){
		Serial.println();
		Serial.print(c,HEX);
		Serial.print(": ");
		for (i=0;i<16;i++){
			hexprint(buffer[i+c*16]);
			Serial.print(' ',BYTE);
		}
		for (i=0;i<16;i++){
			if ((buffer[i+c*16] > 31) && (buffer[i+c*16] <= 'z'))
				Serial.print(buffer[i+c*16],BYTE);	
			else
				Serial.print('.',BYTE);
			
		}
	}
}



/***************************************************************************
*   Name:			MMC_tester
*	Description:	Check out basic MMC functions
*	Parameters:		none
*	Returns:	Status byte, non-zero for failure.
***************************************************************************/
unsigned char MMC_tester(void)
{
	unsigned char c;
	unsigned short cstatus;
	unsigned long cap;
	
	c =  card.reset();				// init mmc
	Serial.print("MMC_RESET returned ");
	Serial.print(c,DEC);
	Serial.println();
	if (c==0){
		cstatus = card.check();				// check status
		Serial.print("MMC_SEND_STATUS returned ");
		Serial.print(cstatus,DEC);
		c = (unsigned char) cstatus;
		Serial.println();
	}
	if (c==0){
		c = card.identify();
		Serial.print("MMC_SEND_CID returned ");
		Serial.print(c,DEC);
		if (c==0){ // identity OK
			dump_buffer(2,card.mmc_scratch);// dump 2 lines from the buffer
		}
		c=0;
		Serial.println();
	}
	if (c==0){
		c = card.cardType();
		Serial.print("MMC_SEND_CSD returned ");
		Serial.print(c,DEC);
		if (c==0){ // CSD OK
			dump_buffer(2,card.mmc_scratch);// dump 2 lines from the buffer
		}
		c=0;
		Serial.println();
	}
	if (c==0){
		cap = card.capacity()>>12;
		Serial.print("MMC_Capacity returned ");
		Serial.print(cap,DEC);
		Serial.println();
	}
	
	if (c==0){
		c = card.name();
		Serial.print("MMC_Name returned ");
		Serial.print(c,DEC);
		Serial.print(" ");
		if (c==0){
			Serial.print((char*)card.mmc_scratch);
		}	
		Serial.println();
	}

	if (c == 0) {

		c =  card.read(0x00);// read first sector
		Serial.print("MMC_Read returned ");
		Serial.print(c,DEC);
		Serial.println();
		if (c==0){
			Serial.print("MMC First Sector: ");
			dump_buffer(32,card.mmc_sbuf); // dump the sector
		}
	}
			
	Serial.println();

	
	
	return c;
}

void debug_trigger(char x)
{
  char i;
  for (i=0;i<x;i++){
    digitalWrite(debugpin, LOW);
    digitalWrite(debugpin, HIGH);  
  }
}





/***************************************************************************
*   Name:			FAT_tester
*	Description:	Routines to test filesystem functions to the mmc
*	Parameters:		none
*	Returns:		error code
***************************************************************************/
uint8	FAT_tester(void)
{
	uint8 result,i;
	uint8 record;
	uint8 attrib;
	uint16 sector=0;
//	uint16 cluster;
//	uint32 size;
	
	// set up the FAT variables
	vol.FAT_buffer = card.mmc_sbuf; // 512 byte buffer for sector reads/writes
	vol.rawDev = &card;
	
	result =  card.reset();				// init mmc
	if (result) return result;
	
	result = vol.FAT_initFat16();
	if (result) return result; // abort on non-zero reply 
	
	// print Fat info
	Serial.print("FAT boot Sector info");Serial.println();
	Serial.print("FAT begins at sector ");
	Serial.print(vol.FAT16_fat_begin_lba);Serial.println();
	Serial.print("Clusters begin at sector ");
	Serial.print(vol.FAT16_cluster_begin_lba);Serial.println();
	Serial.print("Sectors per cluster = ");
	Serial.print(vol.FAT16_sectors_per_cluster,DEC);Serial.println();
	Serial.print("Root dir starts at sector ");
	Serial.print(vol.FAT16_root_dir_first_sector);Serial.println();
	
	//show volume label
	result = vol.FAT_get_label(card.mmc_scratch);
	if (!result){
		Serial.print("Volume Name is ");
		Serial.print((char *)card.mmc_scratch);
		Serial.println();
	}
	
	// read the root dir
	sector = vol.FAT16_root_dir_first_sector;
	result = card.read(sector);

	record =0;
	while((result==0) && card.mmc_sbuf[record*32]!=0){
		 // check firstByte
		if (card.mmc_sbuf[record*32] != 0xe5){ // not used (aka deleted)
			
			// get the attrib byte
			attrib = card.mmc_sbuf[(record*32)+11];
			
			if (attrib == FILE_TYPE_FILE || attrib == FILE_TYPE_DIR ){ // entry is normal 8.3 entry
				
				if (attrib == FILE_TYPE_DIR) Serial.print("[");
				
				// construct short filename string
				for (i=0;i<8;i++){ 
					card.mmc_scratch[i] = card.mmc_sbuf[(record*32)+i];
				}
				card.mmc_scratch[8] = '.';
				card.mmc_scratch[9] = card.mmc_sbuf[(record*32)+8];
				card.mmc_scratch[10] = card.mmc_sbuf[(record*32)+9];
				card.mmc_scratch[11] = card.mmc_sbuf[(record*32)+10];
				card.mmc_scratch[12] = 0x00;
				Serial.print((char *)card.mmc_scratch);		
				if (attrib == FILE_TYPE_DIR) Serial.print("]");
				Serial.print("\t");
				
				// get Cluster 
				Serial.print(card.mmc_scratch[13] = card.mmc_sbuf[(record*32)+0x15],HEX);
				Serial.print(card.mmc_scratch[14] = card.mmc_sbuf[(record*32)+0x14],HEX);
				Serial.print(card.mmc_scratch[15] = card.mmc_sbuf[(record*32)+0x1B],HEX);
				Serial.print(card.mmc_scratch[16] = card.mmc_sbuf[(record*32)+0x1A],HEX);
				Serial.print("\t");
				
				
				//get fileSize
				Serial.print(card.mmc_scratch[17] = card.mmc_sbuf[(record*32)+0x1f],HEX);
				Serial.print(card.mmc_scratch[18] = card.mmc_sbuf[(record*32)+0x1e],HEX);
				Serial.print(card.mmc_scratch[19] = card.mmc_sbuf[(record*32)+0x1d],HEX);
				Serial.print(card.mmc_scratch[20] = card.mmc_sbuf[(record*32)+0x1c],HEX);
				Serial.print("\t");
				
				//get filenumber
				Serial.print(record+(sector<<4),HEX);
				Serial.println();
				
			}
			
				
		}
		
		// next record or on to next sector
		record++;
		
		if (record==16){
			record = 0;
			record = 0;
			record = 0;

			sector++;
			result = card.read(sector);
			
		}
	}
	 
	 // print number of files in directory
	
	// get limits of file system.
	
	// play file "test.mp3"
	Serial.println();
	
	return result;
}

void 	cue_file(void)
{
	uint8 check;
//	uint8 temp;
	uint32 ID3index;
	uint8 i;
	uint16 j;
	uint32 offset;
	uint16 ID3_Bytes;
	uint32 ID3_clusters;
	uint16 ID3_sectors;
	uint32 nextCluster=0;
	
	
	// read file data and check gFAT_entry is aValid file entry.
	check = vol.FAT_readFile(vol.gFAT_entry,vol.FAT16_dir_first_sector);
	//if (check) return;
	
	if (vol.FAT16_filetype & FILE_TYPE_DIR) return;

	nextCluster=0;
	
	// get first Cluster 
	vol.FAT_Scratch2Cluster();
	
	vol.gFileSectorSize += vol.FAT_scratch[17];
	vol.gFileSectorSize <<= 8;
	vol.gFileSectorSize += vol.FAT_scratch[18];
	vol.gFileSectorSize <<= 8;
	vol.gFileSectorSize += vol.FAT_scratch[19];

	cluster_pos = 0;
	buff_pos = 0;
	vol.FAT_readCluster(vol.gCluster,0);
	
	vol.gFile_good = TRUE;
	vol.gFileSectorsPlayed = 0;
	
	// Detect and Skip ID3 Info at start of file
	// (we ignore tags at end of file)
	
	// Version 1.x 
	if (vol.FAT_buffer[0] == 'T' && vol.FAT_buffer[1] == 'A' && vol.FAT_buffer[2]=='G') {
		//PRINT("ID3 v1 TAG");EOL();
		// jump to byte 128
		buff_pos = 4; 
	}else
		
	// Version 2.x - now with very basic interpretation!
	if (vol.FAT_buffer[0] == 'I' && vol.FAT_buffer[1] == 'D' 
			  && vol.FAT_buffer[2]=='3'){ 
		//PRINT("ID3 v2.");
		//UART_Printfu08(FAT_buffer[5]);
		//UART_Printfu08(FAT_buffer[4]);
		//PRINT(" TAG");

      
		/*
		An ID3v2 tag can be detected with the following pattern:
		$49 44 33 yy yy xx zz zz zz zz
		Where yy is less than $FF, xx is the 'flags' byte and zz is less than $80.
		z = ID3 tag length.
		 */
		
		offset = 0;
		for(i=6;i<10;i++){
			offset <<= 7; // only shift by 7 as MSB is unused.
			offset += vol.FAT_buffer[i];
		}



      
		offset += 10; //include length of header
		//UART_Printfu32(offset);PRINT("B");EOL();

      // offset is now equal to the the length of the TAG
      ID3index = 10; // skip header

		// skip through to end of ID3 
		ID3_clusters = (offset/512) / vol.FAT16_sectors_per_cluster;
		ID3_sectors = (offset/512) % vol.FAT16_sectors_per_cluster;
		ID3_Bytes = offset % 512;
		
		//UART_Printfu32(ID3_clusters);EOL();
		//UART_Printfu16(ID3_sectors);EOL();
		//UART_Printfu16(ID3_Bytes);EOL();
		
		// find first cluster of actual song
		for (j=0;j<ID3_clusters;j++){
			
			nextCluster = vol.FAT_NextCluster(vol.gCluster);
		//	UART_Printfu16(j);UART_SendByte(0x09);
		//	UART_Printfu32(nextCluster);EOL();
			if (nextCluster == 0xffffffff){
				vol.gFile_good = FALSE;
				PRINT("EOF: ID3 Tag @ Clstr ");
				Serial.print(vol.gCluster,HEX);
				EOL();
				return;
			}
			vol.gCluster = nextCluster;
		}

		
		// Adjust variables for new position.
		vol.gFileSectorsPlayed = (offset / 512);
		buff_pos = (ID3_Bytes/32);
		cluster_pos = ID3_sectors;

		/*
		while(FAT_readCluster(gCluster,cluster_pos)){
			MMC_Reset();	
		}
		*/	
		
		/*PRINT("ID3 Tag skipped. First ten bytes of MP3 stream are ... ");
		for (i=0;i<10;i++){
			UART_Printfu08(FAT_buffer[i+ID3_Bytes]);
		}
		EOL();
		*/
		j=ID3_Bytes % 32;
		if (j){//we need to play(skip;) some bytes
			buff_pos++; // skips to next 32 byte chunk of buffer
		}
	}else{ //dump  first 10 bytes of file
		/*
		for (i=0;i<10;i++){
			UART_Printfu08(FAT_buffer[i]);
		}
		EOL();
		 */
	}
	
	// send params to vs1001k
//	flush_decoder(SOFT_RESET); 	
	
	//reset play timer...
	//vol.gPlayTimeSeconds = 0;
	return;
}

/**
*	Data Streaming
*
*	Take care of feeding data to mp3 chip and reading 
*	mmc in free time. AKA playing.
**/   
void 	streaming (void)
{
//	uint16 c;
	uint8	abort=0;
//	uint16 tmp=0;
//	uint16 state[2];
	uint32 nextfile;

	
	//if (!vol.gFile_good) return; // only run if we have a valid file.
	
	if (buff_pos>15) { // we need to get a new sector

		vol.gFileSectorsPlayed++;
		
		if (cluster_pos>vol.FAT16_sectors_per_cluster-1){ // need new cluster
			cluster_pos=0;
			vol.gCluster = vol.FAT_NextCluster(vol.gCluster);

		}
		
		if (vol.gCluster == 0xffffffff) { // finished song. on to next ?
			
			// Stop all playing and reset everything
			vol.gFile_good = FALSE;
			////gMode = MODE_STOP;
			card.reset();
			////flush_decoder(SOFT_RESET);

			return;
		}
		
		// read sector from MMC up to 255 times
		while (vol.FAT_readCluster(vol.gCluster,cluster_pos)&& (--abort)){
			card.reset(); // reset if read failed.
		}
		
		buff_pos=0;
		cluster_pos++; // increment for next time
	}
	
	// need to send data to mp3?
	// send at most the rest of sector in memory.
	while (bit_is_set(DREQ_PORT,DREQ_PIN) && (buff_pos<16)){
         
		player.send_32(vol.FAT_buffer+(32*buff_pos++));
	}
	
	return;
}


int main(void)
{
	init();

	setup();
    
	for (;;)
		loop();
        
	return 0;
}

